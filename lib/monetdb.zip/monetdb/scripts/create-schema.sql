CREATE SCHEMA "public" AUTHORIZATION "monetdb";
ALTER USER "monetdb" SET SCHEMA "public";