rm -rf data
monetdbd create /home/user4/programs/monetdb/data
monetdbd set port=54321 /home/user4/programs/monetdb/data
monetdbd start /home/user4/programs/monetdb/data
monetdb create dataflow_analyzer
monetdb release dataflow_analyzer
cd scripts
mclient -p 54321 -d dataflow_analyzer /home/user4/programs/monetdb/scripts/create-schema.sql
monetdb-run-script-db database-script.sql
monetdb-stop-all
cd ..
